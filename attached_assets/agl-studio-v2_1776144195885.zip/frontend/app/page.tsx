export default function Home() {
  return (
    <main style={{ padding: 40 }}>
      <h1>AGL Studio V1</h1>
      <p>Staking + AI Security Platform</p>
    </main>
  );
}
