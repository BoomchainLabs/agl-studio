
"use client"

import { useAccount, useConnect } from "wagmi"

export default function Navbar() {
  const { address } = useAccount()
  const { connect, connectors } = useConnect()

  return (
    <div className="flex justify-between p-4 border-b border-white/10">
      <div className="font-bold">AGL Studio</div>

      <button
        onClick={() => connect({ connector: connectors[0] })}
        className="px-3 py-1 rounded bg-cyan-600"
      >
        {address ? address.slice(0,6) + "..." : "Connect"}
      </button>
    </div>
  )
}
