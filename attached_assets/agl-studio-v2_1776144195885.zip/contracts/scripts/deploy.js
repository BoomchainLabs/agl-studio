async function main() {
  const [deployer] = await ethers.getSigners();

  const Token = await ethers.getContractFactory("AGLToken");
  const token = await Token.deploy();

  await token.waitForDeployment();

  const Staking = await ethers.getContractFactory("AGLStaking");
  const staking = await Staking.deploy(await token.getAddress());

  await staking.waitForDeployment();

  console.log("Token:", await token.getAddress());
  console.log("Staking:", await staking.getAddress());
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
