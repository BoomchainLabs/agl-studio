
export const AGL_STAKING_ADDRESS = "0xYOUR_STAKING_CONTRACT_ADDRESS"

export const stakingAbi = [
  "function stake(uint256 amount)",
  "function unstake(uint256 amount)",
  "function claimRewards()",
  "function earned(address) view returns (uint256)",
  "function stakedBalance(address) view returns (uint256)",
  "function totalStaked() view returns (uint256)",
  "function getAPY() view returns (uint256)"
]
