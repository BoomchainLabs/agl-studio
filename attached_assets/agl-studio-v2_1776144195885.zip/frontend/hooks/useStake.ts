
"use client"

import { useWriteContract, useAccount } from "wagmi"
import { parseUnits } from "viem"
import { AGL_STAKING_ADDRESS, stakingAbi } from "@/lib/contracts"

const tokenAbi = [
  "function approve(address spender, uint256 amount) returns (bool)"
]

export function useStake() {
  const { address } = useAccount()
  const { writeContract, isPending, data } = useWriteContract()

  const approve = (amount: string) => {
    writeContract({
      address: "0xEA1221B4d80A89BD8C75248Fae7c176BD1854698",
      abi: tokenAbi,
      functionName: "approve",
      args: [AGL_STAKING_ADDRESS, parseUnits(amount, 18)]
    })
  }

  const stake = (amount: string) => {
    writeContract({
      address: AGL_STAKING_ADDRESS,
      abi: stakingAbi,
      functionName: "stake",
      args: [parseUnits(amount, 18)]
    })
  }

  const unstake = (amount: string) => {
    writeContract({
      address: AGL_STAKING_ADDRESS,
      abi: stakingAbi,
      functionName: "unstake",
      args: [parseUnits(amount, 18)]
    })
  }

  const claim = () => {
    writeContract({
      address: AGL_STAKING_ADDRESS,
      abi: stakingAbi,
      functionName: "claimRewards"
    })
  }

  return { approve, stake, unstake, claim, isPending, txHash: data, address }
}
