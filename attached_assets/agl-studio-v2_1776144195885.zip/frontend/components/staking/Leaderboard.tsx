
"use client"

export default function Leaderboard() {
  const users = [
    { addr: "0x1234...abcd", stake: "1200 AGL" },
    { addr: "0x5678...efgh", stake: "900 AGL" },
    { addr: "0x9999...zzzz", stake: "450 AGL" }
  ]

  return (
    <div className="p-4 border border-white/10 rounded-xl">
      <h2 className="font-semibold mb-3">Top Stakers</h2>

      {users.map((u, i) => (
        <div key={i} className="flex justify-between text-sm py-1">
          <span>{u.addr}</span>
          <span className="text-cyan-400">{u.stake}</span>
        </div>
      ))}
    </div>
  )
}
