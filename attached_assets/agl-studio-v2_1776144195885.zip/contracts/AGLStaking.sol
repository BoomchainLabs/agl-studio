// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/security/ReentrancyGuard.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

contract AGLStaking is Ownable, ReentrancyGuard {
    IERC20 public token;

    uint256 public rewardRate = 1e15;
    uint256 public totalStaked;

    mapping(address => uint256) public balance;
    mapping(address => uint256) public rewards;
    mapping(address => uint256) public lastUpdate;

    constructor(address _token) {
        token = IERC20(_token);
    }

    function stake(uint256 amount) external {
        require(amount > 0);
        _update(msg.sender);

        token.transferFrom(msg.sender, address(this), amount);
        balance[msg.sender] += amount;
        totalStaked += amount;
    }

    function unstake(uint256 amount) external {
        require(balance[msg.sender] >= amount);
        _update(msg.sender);

        balance[msg.sender] -= amount;
        totalStaked -= amount;

        token.transfer(msg.sender, amount);
    }

    function claim() external {
        _update(msg.sender);
        uint256 reward = rewards[msg.sender];
        rewards[msg.sender] = 0;
        token.transfer(msg.sender, reward);
    }

    function _update(address user) internal {
        uint256 time = block.timestamp - lastUpdate[user];
        rewards[user] += balance[user] * rewardRate * time;
        lastUpdate[user] = block.timestamp;
    }
}
