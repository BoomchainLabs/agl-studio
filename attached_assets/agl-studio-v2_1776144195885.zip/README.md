# AGL Studio V1

Full Web3 staking + AI security studio

## Stack
- Next.js (frontend + API routes)
- Wagmi + Viem
- Solidity (staking + token)
- Hardhat

## Run Frontend
cd frontend
npm install
npm run dev

## Deploy Contracts
cd contracts
npm install
npx hardhat compile
npx hardhat run scripts/deploy.js --network base
