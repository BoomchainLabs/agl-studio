
"use client"

export default function TxStatus({ status }: { status: string }) {
  const color =
    status === "success"
      ? "text-green-400"
      : status === "error"
      ? "text-red-400"
      : status === "pending"
      ? "text-yellow-400"
      : "text-gray-400"

  return <div className={color + " text-sm"}>{status.toUpperCase()}</div>
}
