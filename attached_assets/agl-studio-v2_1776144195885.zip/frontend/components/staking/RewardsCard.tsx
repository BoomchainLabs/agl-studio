
"use client"

import { useAccount, useReadContract } from "wagmi"
import { AGL_STAKING_ADDRESS, stakingAbi } from "@/lib/contracts"

export default function RewardsCard() {
  const { address } = useAccount()

  const { data } = useReadContract({
    address: AGL_STAKING_ADDRESS,
    abi: stakingAbi,
    functionName: "earned",
    args: address ? [address] : undefined
  })

  return (
    <div className="p-4 rounded-xl border border-white/10 bg-white/5">
      <h3 className="text-sm text-gray-400">Earned Rewards</h3>
      <p className="text-2xl font-bold text-cyan-400">
        {data ? Number(data) / 1e18 : 0} AGL
      </p>
    </div>
  )
}
