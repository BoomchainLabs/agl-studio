
"use client"

import { useAccount } from "wagmi"
import { motion } from "framer-motion"
import RewardsCard from "@/components/staking/RewardsCard"
import Leaderboard from "@/components/staking/Leaderboard"
import { useStake } from "@/hooks/useStake"

export default function Dashboard() {
  const { address } = useAccount()
  const { stake, unstake, claim, approve } = useStake()

  return (
    <main className="p-6 space-y-6 text-white">
      <motion.h1 initial={{opacity:0,y:-10}} animate={{opacity:1,y:0}} className="text-3xl font-bold">
        AGL Studio V2
      </motion.h1>

      <p className="text-gray-400">
        Wallet: {address ?? "Not connected"}
      </p>

      <div className="grid md:grid-cols-2 gap-4">
        <RewardsCard />
        <Leaderboard />
      </div>

      <div className="flex gap-3 flex-wrap">
        <button onClick={() => approve("10")} className="px-3 py-2 bg-yellow-600 rounded">
          Approve
        </button>

        <button onClick={() => stake("10")} className="px-3 py-2 bg-cyan-600 rounded">
          Stake
        </button>

        <button onClick={() => unstake("10")} className="px-3 py-2 bg-red-600 rounded">
          Unstake
        </button>

        <button onClick={() => claim()} className="px-3 py-2 bg-green-600 rounded">
          Claim
        </button>
      </div>
    </main>
  )
}
